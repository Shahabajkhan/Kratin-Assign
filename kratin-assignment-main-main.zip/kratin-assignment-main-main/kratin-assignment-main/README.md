# Healthify - Kratin Assesment Project

Healthify is a web application for sunita,a 65+ years old woman to help her live healthy and happy life.

### Features

-   Diet Plan
-   Yoga Suggestions
-   BMI Calculator

# Problem statement 
How can you help Sunita Sharma (65+ years old) to live a healthier and better life?

### Deployment link 
- https://kratin-assignment.vercel.app/

### Company
- kratin software solutions pvt ltd


